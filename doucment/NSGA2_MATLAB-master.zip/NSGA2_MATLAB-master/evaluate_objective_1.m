function f = evaluate_objective(x, M, V, i)
f = [];
global answer
global choice
load train_F.mat;
load train_L.mat;
load test_F.mat;
load test_L.mat;
temp_x = x(1:V);
inmodel = temp_x>choice;%%%%%�趨ǡ������ֵѡ������
f(1) = sum(inmodel(1,:));
answer(i,1)={f(1)};
model = libsvmtrain(train_L,train_F(:,inmodel), '-s 0 -t 2 -c 1.2 -g 2.8');
[predict_label, ~, ~] = libsvmpredict(test_L,test_F(:,inmodel),model,'-q'); 
error=0;
for j=1:length(test_L)
    if(predict_label(j,1) ~= test_L(j,1))
        error = error+1;
    end
end
error = error/length(test_L);
f(2) = error;
answer(i,2)={error};
answer(i,3)={inmodel};
end