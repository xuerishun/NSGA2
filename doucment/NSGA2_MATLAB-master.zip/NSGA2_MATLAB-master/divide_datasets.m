function divide_datasets()
load Parkinson.mat;%ѡ�ĵ����ݼ����UCI������
dataMat=Parkinson_f;
len=size(dataMat,1);
%��һ��
maxV = max(dataMat);
minV = min(dataMat);
range = maxV-minV;
newdataMat = (dataMat-repmat(minV,[len,1]))./(repmat(range,[len,1]));

Indices   =  crossvalind('Kfold', length(Parkinson_label), 10);
site = find(Indices==1|Indices==2|Indices==3);
train_F = newdataMat(site,:);
train_L = Parkinson_label(site);
site2 = find(Indices~=1&Indices~=2&Indices~=3);
test_F = newdataMat(site2,:);
test_L =Parkinson_label(site2);
save train_F train_F;
save train_L train_L;
save test_F test_F;
save test_L test_L;
end
%what doesn't kill you makes you stronger, stand a little taller,doesn't mean i'm over cause you're gonw.